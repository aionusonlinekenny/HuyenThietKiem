----------------------------------
--	Copyright: JX Online by Kinnox Team
--	Author: Kinnox
--	Date: 06/06/2014
--	Desc: Script GM Item
----------------------------------

----------------------------
--
----------------------------
function GM_Item()
	local sInfo =  "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {
			"[1] - Nh�n Questkey th��ng/I_QK_Normal",
			"[2] - Nh�n ng�n l��ng/GM_Money",
			"[3] - Tr� v�/GM_Choose",
			"[4] - Tho�t/ExitFunc",
		}
	SayImage(sInfo,"44/44/15",getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function I_QK_Normal()
	AskClientForNumber("R_I_QK_Normal" ,0,1316,"Nh�p ID.")
end
function GM_Money()
	AskClientForNumber("GM_Money1" ,0,999999999,"Nh�p s� ti�n.")
end	
function GM_Money1(num)
Earn(num)
end
----------------------------
--
----------------------------
function R_I_QK_Normal(nId)
	AddEventItem(tonumber(nId))
end