----------------------------------
--	Copyright: JxOnline by kinnox;
--	Author: kinnox
--	Date: 15/11/2021
--	Desc: Script GM Item
----------------------------------

----------------------------
--
----------------------------
function GM_Item()
	local sInfo =  "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!G�i �:\nTh�n h�nh ph�[ID:20] --- LB Phong l�ng ��[ID:12]\nSTG[ID:7->11]"
	local tbSay = {
			"Nh�n Task Item/GMTask",
			"Nh�n Script Item/GMScript",
			"Nh�n Gold Item/GMGold",
			"Nh�n Ng�a/GMHouse",
			"Nh�n Item/GMItem",
			"Nh�n ng�n l��ng/GMMoney",
			"Nh�n xu/GMCoin",
			"Tho�t/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end
function GMHouse()
	AskClientForNumber("AddHouseItems" ,0,9999,"Nh�p ID.")
end
function AddHouseItems(nIndex,nID)
	AddItem(0,10,nID,10,5,0,0,0);
end
function GMCoin()
	for j=0,500 do
	AddTaskItem(19);
	end
end	
function GMMoney()
	Earn(2000000)
end	
function GMGold()
	AskClientForNumber("AddGoldItems" ,0,9999,"Nh�p ID.")
	end;
	
function AddGoldItems(nIndex,nID)
	AddGoldItem(nID);
	Msg2Player("C�c h� nh�n ���c v�t ph�m TaskItem "..nID.."");
end;
function GMTask()
AskClientForNumber("AddTaskItems" ,0,999,"Nh�p ID.")
end;

function AddTaskItems(nIndex,nID)
AddTaskItem(nID);
Msg2Player("C�c h� nh�n ���c v�t ph�m TaskItem "..nID.."");
end;
function GMItem()
	AskClientForNumber("AddItems" ,0,999,"Nh�p ID.")
	end;
	
function AddItems(nIndex,nID)
	local i = nID;
	AddItem(0,2,i,10,0,0,0)
	Msg2Player("C�c h� nh�n ���c v�t ph�m "..nID.."");
end;
function GMScript()
AskClientForNumber("AddScriptItems" ,0,999,"Nh�p ID.")
end;

function AddScriptItems(nIndex,nID)
AddScriptItem(nID);
Msg2Player("C�c h� nh�n ���c v�t ph�m ScriptsItem");
end;

function ExitFunc()
end