----------------------------------
--	Copyright: JxOnline by kinnox;
--	Author: [Kinnox]
--	Date: 15/11/2021
--	Desc: Script Support Char
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\faction_head.lua")
Include("\\script\\lib\\admin\\point.lua")

ZFACTION = {
	[1] = {
		{"Thi�u L�m Ph�i",1},
		{"Thi�n V��ng Bang",2},
	},
	[2] = {
		{"���ng M�n",3},
		{"Ng� ��c Gi�o",4},	
	},
	[3] = {
		{"Nga My Ph�i",5},
		{"Th�y Y�n M�n",6},
		--{"Hoa S�n ph�i",11},
	},
	[4] = {
		{"C�i Bang",7},
		{"Thi�n Nh�n Gi�o",8},
	},
	[5] = {
		{"V� �ang Ph�i",9},
		{"C�n L�n Ph�i",10},
	},
}
----------------------------
--
----------------------------
function GM_Char()
	local sInfo = "<color=gold>H� Th�ng<color>: Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"Gia nh�p m�n ph�i./GM_GoFaction",
			"H�c k� n�ng 90./GM_LearnSkill#80",
			"H�c k� n�ng 120./GM_LearnSkill#120",
			"��i m�u PK./GM_ChangeCamp",
			--"Ti�n H�nh T�y T�y/GM_Reset",
			"Ph�c h�i m�u & mana/GM_Restore",
			--"Nh�n �i�m ti�m n�ng/GM_Point",
			--"Nh�n �i�m k� n�ng/GM_Point",
			"Th�ng ��ng c�p 150./PL_Level",
			"Th�ng 10 c�p [T�i �a 150]./PL_Exp",
			"Nh�n 1000 v�n l��ng./PL_Cash",
			"Nh�n 1 v�n xu./PL_Coin",
			"Th�ng T�i l�nh ��o./PL_LeadLevel",
			"Th�ng Danh v�ng./PL_Repute",
			"Th�ng Ph�c duy�n./PL_Fuyuan",
			"K�t th�c ��i tho�i./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

function GM_Reset()
	local sInfo = "<color=gold>H� Th�ng<color>: Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"T�y �i�m Ti�m N�ng/OnClearProp",
			"T�y �i�m K� N�ng/OnClearMagic",
			"T�y t�t c� c�c �i�m/OnClearAll",
			"K�t th�c ��i tho�i./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end;
----------------------------
--
----------------------------
function GM_GoFaction()
	if(GetFactionNo() >= 0) then
		Talk(1,"","Ng��i �� � trong m�n ph�i.")
		return
	end
	local sInfo = "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {}
	local i = GetSeries() + 1
	for j = 1, getn(ZFACTION[i]) do
		tinsert(tbSay, ZFACTION[i][j][1].."/GoFactionA#"..ZFACTION[i][j][2])
	end
	tinsert(tbSay, "Tr� v�./GM_Char")
	tinsert(tbSay, "K�t th�c ��i tho�i./ExitFunc")
	
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function GoFactionA(nSel,nFactionID)
	nFactionID = tonumber(nFactionID)
	if(type(nFactionID) ~= "number") then return end
	if( (nFactionID < 1) or (nFactionID > 11)) then return end
	return Faction:JoinFaction(nFactionID)
end

----------------------------
--
----------------------------
function GM_LearnSkill(nSel,nLevel)
	nLevel = tonumber(nLevel)
	if(type(nLevel) ~= "number") then return end
	
	local nFactionID = GetFactionNo() + 1
	if(nFactionID == 0) then
		Talk(1,"","Ch�a gia nh�p m�n ph�i kh�ng th� h�c k� n�ng.")
		return
	end
	local tbMessage = {
			"<color=green>Ch�c m�ng ��i hi�p �� h�c ���c k� n�ng "..nLevel.." "..Faction.TFACTION_INFO[nFactionID].sFactionName..".",
			"Ng��i �� l�nh h�i k� n�ng n�y r�i!",
			"H�y luy�n l�n ��ng c�p "..nLevel.." ��.",
		}
	
	if(GetLevel() < nLevel) then
		Msg2Player(tbMessage[3])
		return
	end
		
	if(nLevel == 80) then
		if (HaveMagic(Faction.TFACTION_INFO[nFactionID].tbSkill90[1][2]) >= 20) then
			Msg2Player(tbMessage[2])
			return
		end
		local nCount = getn(Faction.TFACTION_INFO[nFactionID].tbSkill90)
		local nMagicLevel = 20
		for i = 1, nCount do
			if(nFactionID > 2 and nCount > 2) then
				if(i == nCount) then
					nMagicLevel = 0
				end
			end
			AddMagic(Faction.TFACTION_INFO[nFactionID].tbSkill90[i][2], Faction.TFACTION_INFO[nFactionID].tbSkill90[i][3])
		end
		Msg2Player(tbMessage[1])
		
	elseif(nLevel == 120) then
		if (HaveMagic(Faction.TFACTION_INFO[nFactionID].tbSkill120[2]) >= 20) then
			Msg2Player(tbMessage[2])
			return
		end 
		AddMagic(Faction.TFACTION_INFO[nFactionID].tbSkill120[2], Faction.TFACTION_INFO[nFactionID].tbSkill120[3])
		Msg2Player(tbMessage[1])
	end
end

----------------------------
--
----------------------------
function GM_ChangeCamp()
	local sInfo = "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {
			"T�n th�./GM_ChangeCamp_1#1",
			"Ch�nh ph�i./GM_ChangeCamp_1#2",
			"T� ph�i./GM_ChangeCamp_1#3",
			"Trung l�p./GM_ChangeCamp_1#4",
			"S�t th�./GM_ChangeCamp_1#5",
			"Tr� v� tr��c./WPlayer_Char",
			"Tho�t ra./ExitFunc",
		}
	SayImage(sInfo,"44/44/15",getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function GM_ChangeCamp_1(nCamp)
	-- if(GetCamp() == 0) then
		-- Talk(1,"","T�n th� kh�ng th� ��i.")
		-- return
	-- end
	-- if(GetTongID() > 0) then
		-- Talk(1,"","Th�nh vi�n bang h�i kh�ng th� ��i.")
		-- return
	-- end
	nCamp = tonumber(nCamp)
	SetCurCamp(nCamp)
	SetCamp(nCamp)
end
----------------------------
--
----------------------------
function GM_Restore()
	RestoreLife();
	RestoreMana();
end;
----------------------------
--
----------------------------
function GM_Point(nSel)

	if (nSel == 6) then
		AddProp(5000);
	elseif (nSel == 7) then
		AddMagicPoint(1000);
	end;
	KickOutSelf();
end;
----------------------------
--
----------------------------
function ExitFunc()
end;