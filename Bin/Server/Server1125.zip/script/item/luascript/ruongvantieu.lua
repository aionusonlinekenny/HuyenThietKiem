-- Ruong V?n Ti�u - V?n Ti�u Event Reward Box
-- Ported from ThienDieuOnline to HuyenThietKiem
-- Author: Claude AI Assistant
-- Date: 2025-11-17
-- Updated: 2025-11-18 - Using ThienDieu reward logic

Include("\\script\\lib\\TaskLib.lua")

-- Helper function: Random select from list
function RANDOMC(...)
	local tArgs = arg
	local nCount = getn(tArgs)
	if nCount <= 0 then
		return 0
	end
	return tArgs[random(1, nCount)]
end

-- Equipment reward table (replacing Th? Trang B?)
-- HuyenThietKiem doesn't have items 4827-4835, use random equipment instead
AWARD_EQUIPMENT = {
	{0, 102, 70, 30}, -- �o (Armor)
	{0, 103, 30, 30}, -- N�n (Helm)
	{0, 100, 10, 30}, -- Vu kh� (Weapon)
	{0, 101, 10, 30}, -- Nh?n (Ring)
	{0, 108, 30, 30}, -- H? uy?n (Cuff)
	{0, 107, 30, 30}, -- H�i (Boot)
	{0, 104, 30, 30}, -- �ai (Belt)
	{0, 105, 30, 30}, -- Ng?c b?i (Pendant)
}

-- B� k�p 90 theo m�n ph�i
TAB_Menpai = {
	{318, 321, 319},  -- Thi?u L�m (Shaolin)
	{323, 325, 322},  -- Thi�n Vuong (Tianwang)
	{302, 339, 342, 351},  -- �u?ng M�n (Tangmen)
	{353, 355, 390},  -- Ngu �?c (Wudu)
	{380, 381, 382},  -- Nga My (Emei)
	{362, 363, 364},  -- Th�y Y�n (Cuiyan)
	{372, 373, 375},  -- C�i Bang (Gaibang)
	{334, 335, 336},  -- Thi�n Nh?n (Tianren)
	{348, 349, 350},  -- V� �ang (Wudang)
	{313, 314, 315},  -- C�n L�n (Kunlun)
}

-- Main function
function OnUse(nItemIdx)
	-- Check inventory space
	local nFreeSpace = CalcFreeItemCellCount()
	if nFreeSpace < 5 then
		Talk(1, "", "H�nh trang kh�ng �� ch� tr�ng! C�n �t nh�t <color=yellow>5 � tr�ng<color> �� m� r���ng.")

		return 0
	end

	-- Open chest using ThienDieu logic
	levatchung()
	return 1
end

function levatchung()
	local sel = random(1, 50)
	local szName = GetName()

	if (sel > 47) then
		-- 6% chance (3/50): Random equipment level 30+
		local nIdx = random(1, getn(AWARD_EQUIPMENT))
		local equip = AWARD_EQUIPMENT[nIdx]
		local nItemIdx = AddItem(equip[1], equip[2], equip[3], equip[4], 0, 0, 0)
		if nItemIdx > 0 then
			SetItemBindState(nItemIdx, 1)
		end
		Msg2Player("B�n nh�n ���c <color=yellow>Trang B� C�p 30+<color>")
Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>Trang B� Qu�<color> t� B�o R��ng V�n Ti�u!")

	elseif (sel == 47) then
		-- 2% chance (1/50): B� k�p 90
		-- Try to give faction-specific skill book
		local nFaction = GetFaction()
		if nFaction and nFaction ~= "" then
			local nMenpaiIdx = 1
			if nFaction == "shaolin" then nMenpaiIdx = 1
			elseif nFaction == "tianwang" then nMenpaiIdx = 2
			elseif nFaction == "tangmen" then nMenpaiIdx = 3
			elseif nFaction == "wudu" then nMenpaiIdx = 4
			elseif nFaction == "emei" then nMenpaiIdx = 5
			elseif nFaction == "cuiyan" then nMenpaiIdx = 6
			elseif nFaction == "gaibang" then nMenpaiIdx = 7
			elseif nFaction == "tianren" then nMenpaiIdx = 8
			elseif nFaction == "wudang" then nMenpaiIdx = 9
			elseif nFaction == "kunlun" then nMenpaiIdx = 10
			end

			if TAB_Menpai[nMenpaiIdx] then
				local nSkillIdx = random(1, getn(TAB_Menpai[nMenpaiIdx]))
				local nSkillID = TAB_Menpai[nMenpaiIdx][nSkillIdx]
				-- Note: AddMagicScript may not exist in HuyenThietKiem, use AddItem instead
				-- AddItem for skill book: Genre 7, Detail 15 = �?i Th�nh B� K�p 90
				local nItemIdx = AddItem(7, 15, 1, 0, 0, 0, 0)
				if nItemIdx > 0 then
					SetItemBindState(nItemIdx, 1)
				end
			end
		else
			-- No faction, give generic skill book
			local nItemIdx = AddItem(7, 15, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then
				SetItemBindState(nItemIdx, 1)
			end
		end
		Msg2Player("B�n nh�n ���c <color=yellow>B� K�p 90<color>")
		Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c b� k�p 90 t� B�o R��ng V�n Ti�u!")

	elseif (sel < 47 and sel > 40) then
        -- 12% chance (6/50): Th�y Tinh (Crystals)
        -- Genre 6, Detail 15-18:
        -- 15 = Tinh H�ng B�o Th�ch
        -- 16 = Lam Th�y Tinh (change equipment element)
        -- 17 = T� Th�y Tinh (upgrade equipment)
        -- 18 = L�c Th�y Tinh (change equipment stats)

		local nCrystalType = random(15, 18)
		local nItemIdx = AddItem(6, nCrystalType, 1, 0, 0, 0, 0)
		if nItemIdx > 0 then
			SetItemBindState(nItemIdx, 1)
		end

		local sCrystalName = "Th�y Tinh"
		if nCrystalType == 15 then sCrystalName = "Tinh H�ng B�o Th�ch"
		elseif nCrystalType == 16 then sCrystalName = "Lam Th�y Tinh"
		elseif nCrystalType == 17 then sCrystalName = "T� Th�y Tinh"
		elseif nCrystalType == 18 then sCrystalName = "L�c Th�y Tinh"
		end

		Msg2Player("B�n nh�n ���c <color=yellow>"..sCrystalName.."<color> t� B�o R��ng V�n Ti�u!")
		Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>"..sCrystalName.."<color> t� B�o R��ng V�n Ti�u!")

	elseif (sel <= 40 and sel > 20) then
		-- 40% chance (20/50): Ph�c Duy�n L�
		-- Genre 7, Detail 11-13 (Ph�c Duy�n L� ti�u/trung/��i)
		local nType = random(11, 13)
		local nItemIdx = AddItem(7, nType, 1, 0, 0, 0, 0)
		if nItemIdx > 0 then
			SetItemBindState(nItemIdx, 1)
		end
		Msg2Player("B�n nh�n ���c <color=yellow>Ph�c Duy�n L�<color>!")

	else
		-- 40% chance (20/50): Random common items
		local nRand = RANDOMC(3, 4, 5, 6, 11, 12, 13) -- Various consumables

		if nRand == 3 then
			-- Ti�n Th�o L� (7,3)
			local nItemIdx = AddItem(7, 3, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then SetItemBindState(nItemIdx, 1) end
			Msg2Player("B�n nh�n ���c <color=yellow>Ti�n Th�o L�<color>!")
			Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>Ti�n Th�o L�<color> t� B�o R��ng V�n Ti�u!")

		elseif nRand == 4 then
			-- Ti�n Th�o L� ��c bi�t (7,4)
			local nItemIdx = AddItem(7, 4, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then SetItemBindState(nItemIdx, 1) end
			Msg2Player("B�n nh�n ���c <color=yellow>Ti�n Th�o L� [��c Bi�t]<color>!")
			Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>Ti�n Th�o L� [��c Bi�t]<color> t� B�o R��ng V�n Ti�u!")

		elseif nRand == 5 then
			-- Thi�n S�n B�o L� (7,5)
			local nItemIdx = AddItem(7, 5, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then SetItemBindState(nItemIdx, 1) end
			Msg2Player("B�n nh�n ���c <color=yellow>Thi�n S�n B�o L�<color>!")
			Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>Thi�n S�n B�o L�<color> t� B�o R��ng V�n Ti�u!")

		elseif nRand == 6 then
			-- Qu� Hoa T�u (7,6)
			local nItemIdx = AddItem(7, 6, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then SetItemBindState(nItemIdx, 1) end
			Msg2Player("B�n nh�n ���c <color=yellow>Qu� Hoa T�u<color>!")
			Msg2SubWorld("��i Hi�p <color=yellow>"..szName.."<color> �� nh�n ���c <color=cyan>Qu� Hoa T�u<color> t� B�o R��ng V�n Ti�u!")

		else
			-- Ph�c Duy�n L� (backup)
			local nType = random(11, 13)
			local nItemIdx = AddItem(7, nType, 1, 0, 0, 0, 0)
			if nItemIdx > 0 then SetItemBindState(nItemIdx, 1) end
			Msg2Player("B�n nh�n ���c <color=yellow>Ph�c Duy�n L�<color>!")
		end
	end
	-- Always give some silver
	local nSilver = random(50000, 200000) -- 5-20 v�n
	Earn(nSilver)
	Msg2Player("Nh�n th�m <color=yellow>"..(nSilver/10000).." v�n<color> b�c!")
end

function no()
end
