-- Author:	SkyGold
-- Date:	15-09-2015
-- Th� ��a Ph�
Include("\\script\\lib\\Revivepos.lua")

function OnUse(nIdx)  
	local nW, nX, nY = GetWorldPos()
	if (nW == 341) or (nW == 342) or (nW == 242)then	
		-- nothing;
	else 
		if CheckMapNoForTHP(nW) == 1  or GetTask(601) > 0 then
		Talk(1,"", "N�i n�y kh�ng th� s� d�ng <color=green>Th� ��a ph� <color>.")	
		return end	
	end;
	
	if(GetTownPortalFlag() ~= 0) then
		Msg2Player("N�i n�y kh�ng th� s� d�ng <color=green>Th� ��a ph� <color>.")
		return
	end
	
	if(GetFightState() == 0) then 
		Msg2Player("Tr�ng th�i phi chi�n ��u kh�ng th� s� d�ng <color=green>Th� ��a ph� <color>.")
		return
	end
	DelItemByIndex(nIdx)
	UseTownPortal()
	AddSkillState(963, 1, 0, 18*3)
end

