Include("\\script\\lib\\tasklib.lua");	
Include("\\script\\event\\banhchung\\head.lua");
function OnUse(nIdx)

	if (GetTask(T_EVENT_MAX2) >= MAX_EVENT) then 
		Msg2Player("��i hi�p l� b�c k� t�i trong thi�n h�, �� thu th�p v� s� d�ng h�t b�nh ch�ng, m�i ��i hi�p v� L� Quang nh�n qu�");
		return
	end;

	local EarExp = 1500000;
	local TAB_TaskItem = {
		12,15,16,17,18,22,23,24,25,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59
	}
	local TAB_ScriptItem ={
		3,4,5,6,11,12,13,14,15,16,131,
	}
	local TAB_HorseItem_Limited ={
		{0,10,6,10},
		{0,10,8,10},
		{0,10,7,10}
	}
	local TAB_HorseItem_UnLimited ={
		{0,10,6,10},
		{0,10,8,10},
		{0,10,7,10}
	}


	local nRanTAB = RANDOMC(1,2,3);
	local nRanItem = RANDOMC(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40);
	local bLucky = RANDOMC(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30);
	if (bLucky <= 10) then
		if (nRanTAB == 1) then
			AddTaskItem(TAB_TaskItem[RANDOM(1,getn(TAB_TaskItem))]);
		elseif (nRanTAB == 2) then
			AddScriptItem(TAB_ScriptItem[RANDOM(1,getn(TAB_ScriptItem))]);
		else
			if (nRanItem == 18) then
				local nRanID = RANDOM(1,getn(TAB_HorseItem_Limited));
				AddItem(0,TAB_HorseItem_Limited[nRanID][2],TAB_HorseItem_Limited[nRanID][3],10,random(0,4),10,0,0,0,0,0,0,RANDOMC(5,7,15,30));
			end;
		end;
		Msg2Player("S� d�ng b�nh t�t nh�n ���c <color=green> m�t v�t ph�m ��c bi�t <color> !");
	end;
	AddOwnExp(EarExp);
	SetTask(T_EVENT_MAX2,GetTask(T_EVENT_MAX2)+1);
	Msg2Player("S� d�ng b�nh ch�ng nh�n ���c 1.500.000 �i�m kinh nghi�m!")
	if (GetTask(T_EVENT_MAX2) == MAX_EVENT) then 
		Msg2SubWorld("<color=pink> Ch�c m�ng ��i hi�p "..GetName().." �� s� d�ng Max event b�nh ch�ng c�a m�y ch�! <color>")
	end;
	return 1
end