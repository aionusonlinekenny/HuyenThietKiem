----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Cao Trung Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(495, 50, 1, 3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t cao trung ho�n.<color>")
	return 1
end