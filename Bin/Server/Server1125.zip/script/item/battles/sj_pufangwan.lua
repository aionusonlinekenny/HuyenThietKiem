----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Ph� Ph�ng Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(473, 5, 1,3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t ph� ph�ng ho�n.<color>")
	return 1
end