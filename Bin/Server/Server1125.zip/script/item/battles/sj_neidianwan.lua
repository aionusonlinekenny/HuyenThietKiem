----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: N�i L�i Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(483, 10, 1, 3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t n�i l�i ho�n.<color>")
	return 1
end