Include("\\script\\system_config.lua");
Include("\\script\\lib\\tasklib.lua");
Include("\\script\\event\\quockhanh\\head.lua");

--===============Config Event===============--
DangCapSuDung 	= 60
ToiDaSuDung 	= 50000
TenVatPham		= "Gi� Hoa Qu�c Kh�nh"
SoKinhNghiem	= {{4000000,4},}
MoKhoaVipSau 	= 20000 

-----------------------------------------------

function OnUse(nIdx)
if (GetTask(T_GIOHOAQUOCKHANH) >= ToiDaSuDung) then 
		Msg2Player("��i hi�p l� b�c k� t�i trong thi�n h�, �� thu th�p v� s� d�ng h�t Gi� Hoa Qu�c Kh�nh.");
		return
	end;
	
	nTaskValue = GetTask(T_GIOHOAQUOCKHANH);
	if (GetLevel() < DangCapSuDung) then Talk(1,"","��ng c�p tr�n "..DangCapSuDung.." m�i c� th� s� d�ng v�t ph�m n�y.") return end
	----------------------------------------------------
	if ( nTaskValue >= ToiDaSuDung ) then Talk(1,"","Ng��i �� d�ng <color=red>"..ToiDaSuDung.." c�i "..TenVatPham.." <color>r�i kh�ng th� s� d�ng th�m.") return end
	SetTask(T_GIOHOAQUOCKHANH,GetTask(T_GIOHOAQUOCKHANH)+1);
	----------------------------------------------------
	Msg2Player("<color=white>B�n s� d�ng<color=cyan> "..GetTask(T_GIOHOAQUOCKHANH).."/"..ToiDaSuDung.."<color><color=orange> "..TenVatPham.." <color>nh�n ���c <color=yellow>"..SoKinhNghiem[1][2].."<color> tri�u �i�m kinh nghi�m.")
	AddOwnExp(SoKinhNghiem[1][1])
	
	if random(1,2) == 1 then
        NhanVatPham()
    else
        Msg2Player("L�n n�y kh�ng nh�n ���c qu�, h�y th� l�i!")
    end

    return 1
end

function NhanVatPham()
    if type(FindEmptyPlace)=="function" and FindEmptyPlace(1,1)==0 then
        Talk(1,"","H�y s�p x�p h�nh trang, c�n �t nh�t <color=yellow>1x1<color> � tr�ng!")
        return 0
    end
    local daDung = tonumber(GetTask(T_GIOHOAQUOCKHANH)) or 0

    local BASE = {
        {"Ph�c Duy�n L� (ti�u)",  7, 11, 15},
        {"Ph�c Duy�n L� (trung)", 7, 12, 15},
        {"Ph�c Duy�n L� (��i)",   7, 13, 15},
        {"Ti�n Th�o L�",          7,  3, 15},
        {"Thi�n S�n B�o L�",      7,  5, 15},
        {"Qu� Hoa T�u",           7,  6, 15},
        {"Lam Thu� Tinh",         6, 16,  5},
        {"L�c Thu� Tinh",         6, 18,  5},
        {"T� Thu� Tinh",          6, 17,  5},
        {"Tinh H�ng B�o Th�ch",   6, 15,  5},
        {"Thi�t La H�n",          7,  1,  5},
        {"V� L�m M�t T�ch",       7,  2,  5},
        {"B�n nh��c t�m kinh",    7, 24,  5},
    }

    local VIP = {
        {"� V�n ��p Tuy�t", 10,  6, 1},
        {"Phi�n V� ",       10,  7, 1},
        {"Phi V�n",         10,  8, 1},
        {"X�ch Long C�u",   10,  9, 1},
    }

    local TAB_REWARD = {}
    local n = getn(BASE)
    for i=1,n do TAB_REWARD[i] = BASE[i] end
    if daDung > MoKhoaVipSau then
        local idx = n
        local m = getn(VIP)
        for i=1,m do
            idx = idx + 1
            TAB_REWARD[idx] = VIP[i]
        end
    end

    local total = 0
    for i=1,getn(TAB_REWARD) do total = total + (TAB_REWARD[i][4] or 0) end

    local r = random(1, total)

    local pick, acc = 1, 0
    for i=1,getn(TAB_REWARD) do
        acc = acc + (TAB_REWARD[i][4] or 0)
        if r <= acc then pick = i; break end
    end

    local szName = TAB_REWARD[pick][1]
    local szGr   = TAB_REWARD[pick][2]
    local szDet  = TAB_REWARD[pick][3]

    AddItem(szGr, szDet, 0, 0, 0, 0, 0)
    Msg2Player("Nh�n ���c 1 <color=yellow>"..szName.."<color>.")
    return 1
end

