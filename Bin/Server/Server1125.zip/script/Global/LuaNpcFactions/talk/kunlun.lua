----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: C�n L�n H� Ph�p
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10206)
	elseif(sPlayer_Faction == "kunlun") then
		local sNpcName = format("<color=earth>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/41"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." ��o thu�t kh�ng th� m�t s�m m�t chi�u l� tu luy�n xong! Sao ng��i c�n lang thang n�i ��y?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." gia nh�p <color=green>"..GetTongName().."<color> th�t ��ng t� h�o cho C�n L�n ph�i ch�ng ta!",sImage,0)
				else
					SayImage(""..sNpcName.." Bang h�i <color=green>"..GetTongName().."<color> do "..Faction.SexName[GetSex() + 1].." l�nh ��o th�t kh�ng th� xem th��ng! L�m �� t� C�n L�n th�t l� ��ng m�t m�i! Haha!",sImage,0)
				end
			else
				SayImage(""..sNpcName.." Nghe n�i sau khi ng��i xu�ng n�i �� l�p ch�t c�ng danh, c� nh� ��n s� �� s� mu�i ch�ng ta kh�ng?",sImage,2, "Quay v� C�n L�n./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10209)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10210)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10211)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10212)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10213)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10214)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10215)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10217)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10216)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 4) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10207, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(10) ~= 0) then
		Talk(1,"",10208)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10218, 2, "R�i kh�i T�y V�c./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(10) ~= 0) then
		Talk(1,"",10219)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10220, 2, "Xu�t ph�t th�i./OnReturn", "Qu�n mang theo r�i./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(10) ~= 0) then
		Talk(1,"",10221)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(10)
end