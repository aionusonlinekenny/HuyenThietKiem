-- Author:	Kinnox;
-- Date:	15-04-2021
-- Functions: Le Quan;
Include("\\script\\system_config.lua")
LeQuan = {};
Include("\\script\\event\\banhchung\\head.lua");
function main(nNpcIdx)
 	if (GetName() == GM_01 or GetName() == GM_02 or GetName() == GM_03 or GetName() == GM_04) then
		dofile("script/global/luanpcfunctions/Lequan.lua");
		Msg2Player("Reload this script");
	end;
	local tbSay = {
		--"S� ki�n b�nh ch�ng may m�n/banhchung",
		"Ti�u h�y trang b� kh�ng d�ng/OnRemoveItem",
		"Gi�p ta l�nh h�i tuy�t k� 120 th�t truy�n/OnChooseSkill120",
		"H�y b� m�t m� b�o v� nh�n v�t/OnRemovePW",
		"V�ng quay may m�n/VongQuayMayMan",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say("<color=orange>L� Quan: <color>Ta ���c giao tr�ng tr�ch qu�n l� t�t c� c�c ho�t ��ng l�n b� � t�t c� th�nh th�,th�ng trang. ��u ��u c�ng c� ng��i c�a ta, ng��i c�n g� � ta?",getn(tbSay),tbSay);
end;
function VongQuayMayMan()
	local tbSay = {
      "Quay B�ng Xu(20Xu)/quaytienxu",
      "Quay B�ng Ti�n V�n(150V�n)/quaytienvan",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say("<color=orange>L� Quan: <color>Mu�n th� v�n may th� ph�i c� v�n.",getn(tbSay),tbSay);
end
function quaytienvan()
if GetCash() < 10000*150 then Talk(1,"","C�n 150v �� ch�i v�ng quay may m�n","") return end
SetTask(993,1)
SetTask(994,0)
OpenLucky()
end
function quaytienxu()
if GetTask(104) < 20 then Talk(1,"","C�n 20 Xu �� tham gia") return end
SetTask(993,0)
SetTask(994,1)
OpenLucky()
end
function OnRemoveItem()
OpenGiveBox("��t v�t ph�m v�o trong ","Ti�u h�y v�t ph�m, h�y ��t v�t ph�m c�n ti�u h�y v�o trong.\n\n*L�u �:M�i v�t ph�m ��u c� th� ti�u h�y, h�y c�n tr�ng!","OnDel")
end;

function OnDel()
	local nIndexEquip = 0;
	local nIndex = 0;
	local nCountEquip = 0;
	local nNum = 0;
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	
	if ROOMG ~= 8 then
	return
	end
	for i=0,5 do
		for j=0,3 do
		nIndex = GetROItem(ROOMG,i,j);	
			nCountEquip = nCountEquip + 1;
			nIndexEquip = nIndex;
			DelItemByIndex(nIndexEquip)
		end
	end
	Talk(1,"","Th�nh c�ng ti�u h�y trang b�!")
end;

function OnRemovePW()
	Talk(1,"","Vui l�ng cung c�p <color=yellow>M�t kh�u c�p 2, Email, S�t<color> cho BQT �� h�y b� m�t m� b�o v�!");
end;

function OnChooseSkill120()
	SetTask(899,0);
	local tbSay = {
		"Lu�n h�i. B� Nguy�t Ph�t Tr�n tuy�t k�/OnExcuteSkill120#59",
		"D�ch C�t Kinh. H�p Tinh Y�m tuy�t k�/OnExcuteSkill120#60",
		"��i Bi Ch�.  ��i Th�a Nh� Lai Ch� tuy�t k�/OnExcuteSkill120#61",
		"T�nh Ng�o Tam ��ng. H�n Thi�n Kh� C�ng tuy�t k�/OnExcuteSkill120#62",
		"B�ng Tuy�t S� Dung. Ng� Tuy�t �n tuy�t k�/OnExcuteSkill120#63",
		"L�u Quang Phi V�. M� �nh Tung tuy�t k�/OnExcuteSkill120#64",
		"Tam Sinh H�u H�nh. L��ng Nghi Ch�n Kh� tuy�t k�/OnExcuteSkill120#65",
		"Ng�ng �m Quy Nguy�n. Ma �m ph� Ph�ch tuy�t k�/OnExcuteSkill120#66",
		"Tam Ph�c Chi Kh�. ��o H� Thi�n tuy�t k�/OnExcuteSkill120#67",
		"Thu�n D��ng V� C�c. Xu�n � B�t Nhi�m tuy�t k�/OnExcuteSkill120#68",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say("<color=orange>L� Quan: H�y cho ta bi�t tuy�t k� ��i hi�p mu�n l�nh h�i.<color>",getn(tbSay),tbSay);
end;

function OnExcuteSkill120(nSel, nIndex)
	local nIDItem = tonumber(nIndex);
	SetTask(899,nIDItem);
	OpenGiveBox("��t binh ch��ng k� n�ng 120","Binh ph�p thi�n h� nhi�u v� k�, thi�n bi�n v�n h�a gh�p c�n 1000 v�n l��ng. 6 trang binh ch��ng.","OnRead");
end;



function OnRead()
	local nItemIdx, nG, nD, nP, nL, Ser;
	local nCountItem = 0;
	local nCash = 10000000;
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local nIndexItem={};
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 53 and nP == 1) then
					nIndexItem[1] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 54 and nP == 1) then
					nIndexItem[2] = nItemIdx;
					break;
				end;
			end
		end
	end

	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 55 and nP == 1) then
					nIndexItem[3] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 56 and nP == 1) then
					nIndexItem[4] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 57 and nP == 1) then
					nIndexItem[5] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == 58 and nP == 1) then
					nIndexItem[6] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	local bCount = 0;
	for i = 1,6 do
		if (nIndexItem[i] == nil) then
			Talk(1,"","C�c h� thi�u binh ch��ng k� n�ng 120 s� <color=yellow> "..i.."<color>. Ta c�n �� 6 trang binh ch��ng 120.");
			return
		else
			bCount = bCount + 1;
		end;
	end;
	if (GetCash() < nCash) then
		Talk(1,"","C�ng r�n t�o ra tr�ng s�c r�t l�n, tr�n giang h� n�y ta ch�a m�t l�n n�i th�ch. Mang 1000 v�n ��n ��y.");
		return
	end

	---------------
	if (bCount >= 6) then
		for i = 1,6 do
			DelItemByIndex(nIndexItem[i]);
			nIndexItem[i] = nil;
		end
		nIndexItem = {};
		AddScriptItem(GetTask(899));
		Pay(nCash);
		Msg2Player("<color=yellow>Binh ch��ng n�y �� ���c ta gh�p th�nh m�t b�, ng��i c� th� ��c hi�u n� ���c r�i<color>");
		SetTask(899,0)
		EndGiveBox();
	end;

end;


function OnCancel()
end;