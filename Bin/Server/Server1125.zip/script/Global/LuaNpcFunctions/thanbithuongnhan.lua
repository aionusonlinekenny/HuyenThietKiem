-- Author:	Kinnox;
-- Date:	15-04-2021
-- Functions: Than bi thuong nhan;
Include("\\script\\system_config.lua")
tbthuongnhan = {};

function main(nNpcIdx)
	if (GetName() == GM_01 or GetName() == GM_02 or GetName() == GM_03 or GetName() == GM_04) then
		dofile("script/global/luanpcfunctions/thanbithuongnhan.lua");
		Msg2Player("Reload this script");
	end;
tbthuongnhan:tbthuongnhan(10228);
end;

function tbthuongnhan:tbthuongnhan(nMsgId)
	local tbSay = {
		"C�a h�ng trao ��i Ph�c Duy�n./OnBuy",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say("Ta l� th��ng nh�n T�y V�c, chuy�n b�n nh�ng v�t ph�m qu� hi�m, ng��i c� t� t� m� l�a ch�n.",getn(tbSay),tbSay);
end;

function OnBuy()
	Sale(31);
end;

function OnCancel()
end;