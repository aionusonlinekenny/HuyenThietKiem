Include("\\script\\lib\\TaskLib.lua");
NPCPOS_DUANGUA = {
[176] = {
	{49384,95921,"[Linh Th� Tranh T�i]- ��ch"},
	{42537,103039,"[Linh Th� Tranh T�i]- Xu�t Ph�t"},
}
}
HORSETAB ={
	{727,42125,102452,"1. Chu T��c",48836,95716},
	{1644,42177,102508,"2. Huy�n V�",48904,95786},
	{1502,42232,102564,"3. B�ch H� ",48949,95828},
	{1141,42305,102634,"4. Thanh Long",49009,95884},
	{728,42380,102696,"5. K� L�n",49077,95938},
	{1397,42436,102764,"6. Thi�n �i�u",49147,96008}
};
DAYS = 2510301930
NPC_DUANGUA_ADDED = 0 
FILE_SCRIPT = "\\script\\event\\gambling\\quanngua.lua"
DUANGUATALK = "<color=green>%s<color> �ang di�n ra s� ki�n �ua th�, h�y nhanh ch�n tham gia.";

function add_duangua()
    PlayerIndex = 0
    local sw = SubWorldID2Idx(176)

    -- 1) Add 2 NPC b?ng (d�ch + xu?t ph�t)
    for i = 1, getn(NPCPOS_DUANGUA[176]) do
        local nNpcIndex = AddNpc(229, 1, sw, NPCPOS_DUANGUA[176][i][1], NPCPOS_DUANGUA[176][i][2], 0, NPCPOS_DUANGUA[176][i][3], 1)
        SetNpcScript(nNpcIndex, FILE_SCRIPT)         -- << quanngua.lua d�ng d? cu?c
        SetNpcParam(nNpcIndex, 1, i)                 -- d? script bi?t l� b?ng n�o
    end

    -- 2) LU�N d?m b?o mission 1 m? (d? d?ng h? TIME c?a cu?c ch?y)
    if IsMission(1) == 0 then OpenMission(1) end

    -- 3) Spawn 6 �ng?a�
    spawn_horses()

    -- 4) Reset & m? c?a cu?c NGAY cho b?n test
    duangua_open()

    Msg2SubWorld(format(DUANGUATALK, GetMapName(176)))
end


-------------------------------------
-- SPAWN bi?n & ng?a, kh�ng PK
-------------------------------------
-- STATE
RACE_STATE = RACE_STATE or 0    -- 0: idle, 1: dang mo cua cuoc, 2: dang dua, 3: nhan thuong
RACE_TICK  = RACE_TICK  or 0    -- tick cho bu?c di chuy?n (poll m?i ph�t -> bu?c d�i hon)

-- SPWAN 6 con th� (ng?a)
function spawn_horses()
    local sw = SubWorldID2Idx(176)
    for i = 1, getn(HORSETAB) do
        -- HORSETAB[i] = {templId, startX, startY, name, finishX, finishY}
        local templ  = HORSETAB[i][1]
        local sx     = HORSETAB[i][2]
        local sy     = HORSETAB[i][3]
        local name   = HORSETAB[i][4]
        local npcId  = AddNpc(templ, 1, sw, sx, sy, 0, name, 1)

        -- Luu id d? di?u khi?n sau n�y
        SetMissionV(i, npcId)

        -- T?c d? m?c d?nh + d?ng y�n ? v?ch xu?t ph�t
        SetNpcSpeed(npcId, 12)
        SetPos(floor(sx/32), floor(sy/32), npcId)

        -- G?N SCRIPT �trung t�nh� d? n� kh�ng m? h?p tho?i (v� kh�ng d�ng script quanngua d?t cu?c)
        -- N?u d? tr?ng, engine s? kh�ng g?i main khi click. (gi?m nguy co g�y combat AI b?i script)
        SetNpcScript(npcId, "") 
        -- N?u server b?n c� flag n�o �kh�ng d�nh nhau�, h�y b?t ? d�y (v� d?):
        -- SetNpcParam(npcId, <param_no_attack>, 1)
    end
end

function main(NpcIndex)
	if(PlayerIndex > 0) then
	return end
	local nNo = 0;
	for i=1,getn(HORSETAB) do
		if(GetMissionV(i) == NpcIndex) then
		nNo = i;
		break end
	end
	if(nNo == 0) then
	return end
	for i=7,12 do
		if(GetMissionV(i) == 0) then
		SetMissionV(i, nNo)
		if(i == 12) then	--ngua cuoi cung ve dich
		StopMissionTimer(1,2);
		StartMissionTimer(1,3,7*1080);--7 phut nhan thuong
		SetMissionV(0,0);
		end
		break end
	end
end;



function CheckAndRunDuaNgua()
    local nYr, nMo, nDy, nHr, nMi, nSe = GetTimeNow()
    local currentKey = nYr * 100000000 + nMo * 1000000 + nDy * 10000 + nHr * 100 + nMi
    if currentKey >= DAYS then
        if NPC_DUANGUA_ADDED == 0 then
			duangua_open()
            NPC_DUANGUA_ADDED = 1
        end
    else
        if NPC_DUANGUA_ADDED == 1 then
            del_duangua()
            NPC_DUANGUA_ADDED = 0
        end
    end
end

function del_duangua()
for i = 1,getn(NPCPOS_DUANGUA[176]) do
	ClearMapNpcWithName(176,NPCPOS_DUANGUA[176][i][3]);
	end
end;


-------------------------------------
-- M? C?A CU?C (5 ph�t)
-- KH�NG CloseMission, ch? StartTimer
-------------------------------------
function duangua_open()
    -- KH�NG close/open mission ? d�y n?a
    SetMissionV(0, 0)               -- 0 = chua ch?y
    for i=7,12 do SetMissionV(i,0) end

    -- M? c?a cu?c 60s cho test (5*1080 � 5 ph�t; b?n d?i tu? �). ? d�y cho 60s = 1080
    StartMissionTimer(1, 1, 1080)

    -- set state
    RACE_STATE = 1
    RACE_TICK  = 0

    Msg2SubWorld("<bclr=red><color=yellow>[Linh Th� Tranh T�i]<color><bclr> M? C?A CU?C! Tham gia t?i L�m An (166/201)")
end


-------------------------------------
-- B?T �?U �UA
-------------------------------------
function duangua_batdau()
    PlayerIndex = 0
    local sw = SubWorldID2Idx(176)
    SetMissionV(0, 1)               -- 1 = dang ch?y
    for i=7,12 do SetMissionV(i,0) end

    -- �?t t?t c? v? v?ch xu?t ph�t + tang t?c s?n
    for i=1, getn(HORSETAB) do
        local id = GetMissionV(i)
        if id > 0 then
            SetNpcSpeed(id, 12)
            SetPos(floor(HORSETAB[i][2]/32), floor(HORSETAB[i][3]/32), id)
        end
    end

    -- B?t d?ng h? �gi?a ch?ng�: m�nh s? kh�ng d�ng callback, ch? d�ng polling trong RTimer
    StartMissionTimer(1, 2, 2*18)   -- d? GetMSRestTime(1,2) c� gi� tr? (hi?n th? / ki?m tra)
    RACE_STATE = 2
    RACE_TICK  = 0

    Msg2SubWorld("<color=yellow>Tru?ng dua Th� L�m An: CU?C �UA B?T �?U!")
end


-------------------------------------
-- �?I T?C �? LOGIC (kh�ng d�ng math)
-------------------------------------
function change_duangua()
    if GetMissionV(0) ~= 1 then return end -- kh�ng ph?i l�c dang dua
    for i=1,getn(HORSETAB) do
        local sp = RANDOM(7,10) -- core b?n c� RANDOM()
        SetMissionV(80+i, sp)
        local id = GetMissionV(i)
        if id and id > 0 then SetNpcSpeed(id, sp) end
    end
end

-------------------------------------
-- TICK MOVE: di chuy?n t?ng bu?c t?i d�ch
-- Kh�ng d�ng floor, kh�ng chia /32
-------------------------------------
function tick_move()
    if GetMissionV(0) ~= 1 then return end

    local allDone = 1
    for i=1,getn(HORSETAB) do
        local id = GetMissionV(i)
        if id and id > 0 then
            -- pos hi?n t?i (theo bi?n m�nh luu)
            local x = GetMissionV(40+i)
            local y = GetMissionV(60+i)

            local dx = HORSETAB[i][5] - x   -- d�ch theo lane i
            local dy = HORSETAB[i][6] - y
            local sp = GetMissionV(80+i)
            if sp <= 0 then sp = 8 end

            -- d� v? d�ch?
            if dx == 0 and dy == 0 then
                -- d� x?p h?ng chua?
                if GetMissionV(7) == 0 or GetMissionV(8) == 0 or GetMissionV(9) == 0
                   or GetMissionV(10) == 0 or GetMissionV(11) == 0 or GetMissionV(12) == 0 then
                    for r=7,12 do
                        if GetMissionV(r) == 0 then
                            SetMissionV(r, i) -- i: s? ng?a
                            break
                        end
                    end
                end
            else
                allDone = 0
                -- bu?c theo tr?c X
                local stepX = sp
                if dx < 0 then
                    stepX = -sp
                    if x + stepX < HORSETAB[i][5] then stepX = HORSETAB[i][5] - x end
                else
                    if x + stepX > HORSETAB[i][5] then stepX = HORSETAB[i][5] - x end
                end
                -- bu?c theo tr?c Y
                local stepY = sp
                if dy < 0 then
                    stepY = -sp
                    if y + stepY < HORSETAB[i][6] then stepY = HORSETAB[i][6] - y end
                else
                    if y + stepY > HORSETAB[i][6] then stepY = HORSETAB[i][6] - y end
                end

                x = x + stepX
                y = y + stepY

                -- luu l?i & d?y pos th?t
                SetMissionV(40+i, x)
                SetMissionV(60+i, y)
                SetPos(x, y, id)
            end
        end
    end

    -- n?u t?t c? d� v? d�ch -> ch?t v�ng, m? claim
    if allDone == 1 then
        StopMissionTimer(1, 2) -- d?ng d?i t?c d?
        StopMissionTimer(1, 4) -- d?ng di chuy?n
        SetMissionV(0, 0)      -- h?t dua

        if IsMission(1) == 1 then
            StartMissionTimer(1, 3, 7*1080) -- 7 ph�t nh?n thu?ng
        end
        Msg2SubWorld("<color=yellow>K�t th�c cu�c �ua! H�y ��n NPC �� nh�n th��ng.")
    end
end
-- d?y ng?a ti?n th?ng t? sy -> finishY (m?i tick l�i 30 tiles cho d? th?y)
function race_tick()
    if RACE_STATE ~= 2 then return end

    local all_done = 1
    for i=1, getn(HORSETAB) do
        local id = GetMissionV(i)
        if id > 0 then
            local sx, sy = HORSETAB[i][2], HORSETAB[i][3]
            local fx, fy = HORSETAB[i][5], HORSETAB[i][6]

            -- L?y v? tr� hi?n t?i (kh�ng c� API GetPos -> ta luu progress b?ng MissionV)
            -- D�ng MissionV(20+i) l�m �s? tiles d� di�
            local prog = GetMissionV(20+i)
            if prog == 0 then prog = 0 end

            if prog < 9999 then
                all_done = 0
                -- bu?c di l?n (30 tiles) d? 1 ph�t th?y d?ch chuy?n r� r�ng
                prog = prog + 30

                -- convert start/finish v? tile
                local tx = floor(sx/32)
                local ty = floor(sy/32)
                local ftx = floor(fx/32)
                local fty = floor(fy/32)

                -- ch?y th?ng d?c theo tr?c Y: t? sy -> fy
                -- hu?ng v? ph�a finish (sy > fy)
                local cur_ty = ty - prog
                if cur_ty <= fty then
                    cur_ty = fty
                    prog   = 9999     -- finish
                    -- ghi th? h?ng
                    for rank=7,12 do
                        if GetMissionV(rank) == 0 then
                            SetMissionV(rank, i) -- i l� s? ng?a v? d�ch
                            break
                        end
                    end
                end

                -- d?t l?i pos
                SetPos(tx, cur_ty, id)
                SetMissionV(20+i, prog)
            end
        end
    end

    if all_done == 1 then
        -- xong cu?c dua
        StopMissionTimer(1,2)
        StartMissionTimer(1,3, 7*1080)   -- 7 ph�t nh?n thu?ng
        SetMissionV(0,0)
        RACE_STATE = 3
        RACE_TICK  = 0

        -- th�ng b�o top 2
        Msg2SubWorld("<color=yellow>K?t qu?: V? Nh?t = Linh th� s? "..GetMissionV(7)..", V? Nh� = Linh th� s? "..GetMissionV(8))
    end
end
