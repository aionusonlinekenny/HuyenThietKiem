--Author: Kinnox;
--Date: 21/04/2022;
Include("\\script\\mission\\vuotai\\head.lua");
function OnTimer()
	VA:TIMER_LANGDING(SubWorld); -- 20 seccon call function;
end