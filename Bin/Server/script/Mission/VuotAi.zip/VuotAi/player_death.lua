--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\mission\\vuotai\\head.lua");
function OnDeath(nLauncher,nAttacker)
	--mutil ben thuyen;
	local OldSubWorld = SubWorld;
	local OldPlayerIndex = PlayerIndex;
		PlayerIndex = nLauncher;
	Msg2MSAll(VA.MAIN.MISSION_VA, " "..GetName().." ��i hi�p kh�ng may t� vong khi �ang v��t �i");
	VA:OUT_DEATH(PlayerIndex,2);
	PlayerIndex = OldPlayerIndex;
	SubWorld = OldSubWorld;
end