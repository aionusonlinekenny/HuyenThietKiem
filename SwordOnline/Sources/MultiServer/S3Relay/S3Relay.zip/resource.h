//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by S3Relay.rc
//
#define IDC_MYICON                      2
#define IDD_S3RELAY_DIALOG              102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_S3RELAY                     107
#define IDI_SMALL                       108
#define IDC_S3RELAY                     109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_ROOTLOGIN            129
#define IDC_EDIT_NAME                   1000
#define IDC_EDIT_PSWD                   1001
#define IDM_TRACE_DATASIZE              32771
#define IDM_STARTUP                     32772
#define IDM_SHUTDOWN                    32773
#define IDM_TRACE_IP                    32774
#define IDM_TRACE_MAC                   32775
#define IDM_CLEAR_TRACE                 32776
#define IDM_TRACE_STATUS                32777
#define IDM_UPDATE_TRACE                32778
#define IDM_TRACE_SOCKTHREAD            32779
#define IDM_TRACE_HOSTSERVER            32781
#define IDM_TRACE_CHATSERVER            32782
#define IDM_TRACE_TONGSERVER            32783
#define IDM_TRACE_ROOTCENTER            32786
#define IDM_TRACE_GATEWAYCENTER         32787
#define IDM_TRACE_DBROLECENTER          32788
#define IDM_TRACE_RELAYSERVER           32789
#define IDM_TRACE_RELAYCENTER           32790
#define IDM_TRACE_PLAYER                32792
#define IDM_TRACE_PLAYER_DETAIL         32793
#define IDM_TRACE_FRIENDPLAYER          32794
#define IDM_TRACE_FRIENDAFQS            32795
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
