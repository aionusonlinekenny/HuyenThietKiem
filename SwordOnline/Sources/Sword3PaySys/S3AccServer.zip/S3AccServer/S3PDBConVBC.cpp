//-//
//                                         //
//  File		: S3PDBConVBC.cpp		   //
//	Author		: Yang Xiaodong            //
//	Modified	: 3/25/2003                //
//                                         //
//-//

#include "S3PDBConVBC.h"
#include "KStdAfx.h"
#include "GlobalFun.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

S3PDBConVBC::S3PDBConVBC()
{
}

S3PDBConVBC::~S3PDBConVBC()
{
}
