#ifndef _KSTDAFX_H_
#define _KSTDAFX_H_

#pragma warning( disable : 4786 4800 4355 4146 4273 4503 )

#include <assert.h>

// Windows Header Files:
#include <windows.h>

#endif	// _KSTDAFX_H_